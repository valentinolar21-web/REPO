# ArtGreenOtel — Website

Premium luxury villa website for ArtGreenOtel, Sovata, Romania.

## Quick Start

```bash
npm install
npm run dev
```

Open [http://localhost:5173](http://localhost:5173)

## Build for Production

```bash
npm run build
npm run preview
```

## Deploy

### Netlify
1. Push to GitHub
2. Connect repo in Netlify dashboard
3. Build command: `npm run build`
4. Publish directory: `dist`
5. The `netlify.toml` handles SPA routing automatically

### Vercel
1. Push to GitHub
2. Import in Vercel dashboard
3. Framework preset: Vite
4. The `vercel.json` handles SPA routing automatically

## Replacing Placeholder Links

Search for these placeholders and replace with real URLs:

| File | Placeholder | Replace with |
|------|-------------|--------------|
| `src/components/Rooms.jsx` | `https://airbnb.com` | Real Airbnb listing URLs |
| `src/components/BookNow.jsx` | `https://airbnb.com` | Real Airbnb URL |
| `src/components/BookNow.jsx` | `https://booking.com` | Real Booking.com URL |
| `src/components/BookNow.jsx` | `https://vrbo.com` | Real Vrbo URL |
| `src/components/Footer.jsx` | `https://instagram.com` | Real Instagram page |
| `src/components/Footer.jsx` | `https://facebook.com` | Real Facebook page |
| `src/locales/en/translation.json` | `+40 7xx xxx xxx` | Real phone number |
| `src/locales/ro/translation.json` | `+40 7xx xxx xxx` | Real phone number |

## Adding Real Photos

Replace Unsplash URLs in:
- `src/locales/en/translation.json` → rooms[].img
- `src/locales/ro/translation.json` → rooms[].img
- `src/components/Gallery.jsx` → galleryImages array
- `src/components/Hero.jsx` → background image src
- `src/components/About.jsx` → image src
- `src/components/Spaces.jsx` → spaces[].img
- `src/components/Events.jsx` → cards[].img
- `src/components/BookNow.jsx` → background image src

## Tech Stack

- **React 18** + Vite
- **Tailwind CSS** (custom warm earthy palette)
- **Framer Motion** (scroll animations, lightbox)
- **react-i18next** (Romanian + English, persists to localStorage)
- **react-helmet-async** (SEO meta tags)
- **Lucide React** (icons)

## Customization

- Colors: `tailwind.config.js`
- Fonts: `index.html` (Google Fonts) + `src/index.css`
- Content: `src/locales/en/translation.json` and `src/locales/ro/translation.json`
- Contact email: search for `events@artgreenotel.ro` and `info@artgreenotel.ro`
