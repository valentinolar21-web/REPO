import { Routes, Route } from 'react-router-dom'
import { Helmet } from 'react-helmet-async'
import { useTranslation } from 'react-i18next'
import Navbar from './components/Navbar'
import Hero from './components/Hero'
import About from './components/About'
import Rooms from './components/Rooms'
import Amenities from './components/Amenities'
import Spaces from './components/Spaces'
import Events from './components/Events'
import Gallery from './components/Gallery'
import Location from './components/Location'
import BookNow from './components/BookNow'
import Footer from './components/Footer'

function HomePage() {
  const { t } = useTranslation()
  return (
    <>
      <Helmet>
        <title>{t('meta.title')}</title>
        <meta name="description" content={t('meta.description')} />
        <meta property="og:title" content={t('meta.title')} />
        <meta property="og:description" content={t('meta.description')} />
        <meta property="og:image" content="https://images.unsplash.com/photo-1448375240586-882707db888b?w=1200&auto=format&fit=crop&q=80" />
        <meta property="og:type" content="website" />
      </Helmet>
      <Hero />
      <About />
      <Rooms />
      <Amenities />
      <Spaces />
      <Events />
      <Gallery />
      <Location />
      <BookNow />
    </>
  )
}

function NotFound() {
  const { t } = useTranslation()
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-cream-50 text-center px-6">
      <p className="section-label mb-4">404</p>
      <h1 className="font-display text-5xl text-warm-700 mb-6">Page Not Found</h1>
      <p className="font-body text-text-muted mb-10 max-w-md">
        The page you're looking for doesn't exist or has been moved.
      </p>
      <a href="/" className="btn-primary">Return Home</a>
    </div>
  )
}

export default function App() {
  return (
    <div className="bg-cream-50 text-text-main font-body">
      <Navbar />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
      <Footer />
    </div>
  )
}
