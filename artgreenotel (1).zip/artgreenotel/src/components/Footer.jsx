import { useTranslation } from 'react-i18next'
import { Instagram, Facebook, Mail, Phone, MapPin } from 'lucide-react'

const Logo = () => (
  <div className="flex items-center gap-2">
    <svg width="18" height="22" viewBox="0 0 20 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M10 2 C10 2 2 8 2 16 C2 20 6 22 10 22 C14 22 18 20 18 16 C18 8 10 2 10 2Z" fill="#4A7C4A"/>
      <line x1="10" y1="22" x2="10" y2="12" stroke="#8B6E4E" strokeWidth="1.2" strokeLinecap="round"/>
      <line x1="10" y1="17" x2="6" y2="14" stroke="#8B6E4E" strokeWidth="1" strokeLinecap="round"/>
      <line x1="10" y1="15" x2="14" y2="13" stroke="#8B6E4E" strokeWidth="1" strokeLinecap="round"/>
    </svg>
    <span className="font-display text-lg italic font-normal tracking-wide text-cream-50">
      ArtGreenOtel
    </span>
  </div>
)

const LanguageToggle = () => {
  const { i18n } = useTranslation()
  const currentLang = i18n.language?.startsWith('ro') ? 'ro' : 'en'

  const toggle = (lang) => {
    i18n.changeLanguage(lang)
    localStorage.setItem('artgreenotel_lang', lang)
  }

  return (
    <div className="flex items-center gap-1 font-body text-xs font-medium tracking-wider">
      <button
        onClick={() => toggle('ro')}
        className={`px-2 py-1 transition-colors ${currentLang === 'ro' ? 'text-warm-300' : 'text-white/40 hover:text-warm-300'}`}
      >
        RO
      </button>
      <span className="text-white/20">|</span>
      <button
        onClick={() => toggle('en')}
        className={`px-2 py-1 transition-colors ${currentLang === 'en' ? 'text-warm-300' : 'text-white/40 hover:text-warm-300'}`}
      >
        EN
      </button>
    </div>
  )
}

export default function Footer() {
  const { t } = useTranslation()

  const navLinks = [
    { key: 'rooms', href: '#rooms' },
    { key: 'amenities', href: '#amenities' },
    { key: 'spaces', href: '#spaces' },
    { key: 'events', href: '#events' },
    { key: 'gallery', href: '#gallery' },
    { key: 'location', href: '#location' },
    { key: 'book', href: '#book' },
  ]

  const legalLinks = [
    { labelKey: 'footer.privacy', href: '#' },
    { labelKey: 'footer.terms', href: '#' },
    { labelKey: 'footer.cookies', href: '#' },
  ]

  return (
    <footer className="bg-forest-700 text-white">
      {/* Main footer */}
      <div className="max-content py-16 md:py-20">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="lg:col-span-1">
            <Logo />
            <p className="font-body text-sm font-light text-white/60 mt-5 mb-7 leading-relaxed">
              {t('footer.tagline')}
            </p>
            <div className="flex items-center gap-4">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-white/50 hover:text-warm-300 transition-colors"
                aria-label="Instagram"
              >
                <Instagram size={18} />
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-white/50 hover:text-warm-300 transition-colors"
                aria-label="Facebook"
              >
                <Facebook size={18} />
              </a>
            </div>
          </div>

          {/* Quick links */}
          <div>
            <p className="font-body text-xs font-medium tracking-widest uppercase text-warm-300 mb-6">
              {t('footer.quick_links')}
            </p>
            <ul className="space-y-3">
              {navLinks.map((link) => (
                <li key={link.key}>
                  <a
                    href={link.href}
                    className="font-body text-sm font-light text-white/60 hover:text-white transition-colors"
                  >
                    {t(`nav.${link.key}`)}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <p className="font-body text-xs font-medium tracking-widest uppercase text-warm-300 mb-6">
              {t('footer.contact')}
            </p>
            <ul className="space-y-4">
              <li>
                <a
                  href={`mailto:${t('footer.email')}`}
                  className="flex items-center gap-3 font-body text-sm font-light text-white/60 hover:text-white transition-colors"
                >
                  <Mail size={14} className="text-warm-500 flex-shrink-0" />
                  {t('footer.email')}
                </a>
              </li>
              <li>
                <a
                  href={`tel:${t('footer.phone').replace(/\s/g, '')}`}
                  className="flex items-center gap-3 font-body text-sm font-light text-white/60 hover:text-white transition-colors"
                >
                  <Phone size={14} className="text-warm-500 flex-shrink-0" />
                  {t('footer.phone')}
                </a>
              </li>
              <li className="flex items-start gap-3">
                <MapPin size={14} className="text-warm-500 flex-shrink-0 mt-0.5" />
                <span className="font-body text-sm font-light text-white/60">
                  {t('footer.address')}
                </span>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <p className="font-body text-xs font-medium tracking-widest uppercase text-warm-300 mb-6">
              {t('footer.legal')}
            </p>
            <ul className="space-y-3">
              {legalLinks.map((link) => (
                <li key={link.labelKey}>
                  <a
                    href={link.href}
                    className="font-body text-sm font-light text-white/60 hover:text-white transition-colors"
                  >
                    {t(link.labelKey)}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-white/10">
        <div className="max-content py-5 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="font-body text-xs font-light text-white/40">
            {t('footer.copyright')}
          </p>
          <LanguageToggle />
        </div>
      </div>
    </footer>
  )
}
