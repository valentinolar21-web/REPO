import { useState, useEffect } from 'react'
import { useTranslation } from 'react-i18next'
import { motion, AnimatePresence } from 'framer-motion'
import { Menu, X } from 'lucide-react'
import { useScrollDirection } from '../hooks/useScrollDirection'

const Logo = () => (
  <a href="#home" className="flex items-center gap-2 group">
    <svg width="20" height="24" viewBox="0 0 20 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M10 2 C10 2 2 8 2 16 C2 20 6 22 10 22 C14 22 18 20 18 16 C18 8 10 2 10 2Z" fill="#4A7C4A"/>
      <line x1="10" y1="22" x2="10" y2="12" stroke="#8B6E4E" strokeWidth="1.2" strokeLinecap="round"/>
      <line x1="10" y1="17" x2="6" y2="14" stroke="#8B6E4E" strokeWidth="1" strokeLinecap="round"/>
      <line x1="10" y1="15" x2="14" y2="13" stroke="#8B6E4E" strokeWidth="1" strokeLinecap="round"/>
    </svg>
    <span className="font-display text-xl italic font-normal tracking-wide text-warm-700 group-hover:text-warm-500 transition-colors">
      ArtGreenOtel
    </span>
  </a>
)

const LanguageToggle = ({ className = '' }) => {
  const { i18n } = useTranslation()
  const currentLang = i18n.language?.startsWith('ro') ? 'ro' : 'en'

  const toggle = (lang) => {
    i18n.changeLanguage(lang)
    localStorage.setItem('artgreenotel_lang', lang)
  }

  return (
    <div className={`flex items-center gap-1 font-body text-xs font-medium tracking-wider ${className}`}>
      <button
        onClick={() => toggle('ro')}
        className={`px-2 py-1 transition-colors ${currentLang === 'ro' ? 'text-warm-500' : 'text-text-muted hover:text-warm-500'}`}
      >
        RO
      </button>
      <span className="text-warm-300">|</span>
      <button
        onClick={() => toggle('en')}
        className={`px-2 py-1 transition-colors ${currentLang === 'en' ? 'text-warm-500' : 'text-text-muted hover:text-warm-500'}`}
      >
        EN
      </button>
    </div>
  )
}

export default function Navbar() {
  const { t } = useTranslation()
  const { scrollY } = useScrollDirection()
  const [menuOpen, setMenuOpen] = useState(false)
  const isScrolled = scrollY > 60

  const links = [
    { key: 'rooms', href: '#rooms' },
    { key: 'amenities', href: '#amenities' },
    { key: 'spaces', href: '#spaces' },
    { key: 'events', href: '#events' },
    { key: 'gallery', href: '#gallery' },
    { key: 'location', href: '#location' },
  ]

  useEffect(() => {
    if (menuOpen) {
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = ''
    }
  }, [menuOpen])

  return (
    <>
      <motion.nav
        initial={{ y: -80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6, ease: 'easeOut' }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-400 ${
          isScrolled
            ? 'bg-cream-50/95 backdrop-blur-sm shadow-sm border-b border-warm-100'
            : 'bg-transparent'
        }`}
      >
        <div className="max-content h-[72px] flex items-center justify-between">
          <Logo />

          {/* Desktop nav links */}
          <div className="hidden lg:flex items-center gap-8">
            {links.map((link) => (
              <a
                key={link.key}
                href={link.href}
                className={`font-body text-xs font-medium tracking-widest uppercase transition-colors hover:text-warm-500 ${
                  isScrolled ? 'text-text-muted' : 'text-white/90'
                }`}
              >
                {t(`nav.${link.key}`)}
              </a>
            ))}
          </div>

          {/* Desktop right */}
          <div className="hidden lg:flex items-center gap-6">
            <LanguageToggle />
            <a
              href="#book"
              className="font-body text-xs font-medium tracking-wider uppercase bg-warm-500 text-white px-6 py-3 hover:bg-warm-700 transition-colors"
            >
              {t('nav.book')}
            </a>
          </div>

          {/* Mobile burger */}
          <button
            onClick={() => setMenuOpen(true)}
            className={`lg:hidden p-2 transition-colors ${isScrolled ? 'text-warm-700' : 'text-white'}`}
            aria-label="Open menu"
          >
            <Menu size={22} />
          </button>
        </div>
      </motion.nav>

      {/* Mobile drawer */}
      <AnimatePresence>
        {menuOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="fixed inset-0 bg-black/50 z-[60] lg:hidden"
              onClick={() => setMenuOpen(false)}
            />
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'tween', duration: 0.35, ease: 'easeInOut' }}
              className="fixed top-0 right-0 bottom-0 w-[80vw] max-w-sm bg-cream-50 z-[70] flex flex-col p-8"
            >
              <div className="flex items-center justify-between mb-12">
                <Logo />
                <button onClick={() => setMenuOpen(false)} className="text-warm-700 p-2">
                  <X size={22} />
                </button>
              </div>

              <nav className="flex flex-col gap-6 flex-1">
                {links.map((link) => (
                  <a
                    key={link.key}
                    href={link.href}
                    onClick={() => setMenuOpen(false)}
                    className="font-body text-sm font-medium tracking-widest uppercase text-text-muted hover:text-warm-500 transition-colors border-b border-warm-100 pb-6"
                  >
                    {t(`nav.${link.key}`)}
                  </a>
                ))}
              </nav>

              <div className="mt-auto flex flex-col gap-4">
                <a
                  href="#book"
                  onClick={() => setMenuOpen(false)}
                  className="btn-primary text-center"
                >
                  {t('nav.book')}
                </a>
                <LanguageToggle className="justify-center" />
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  )
}
