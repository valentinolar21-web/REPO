import { motion } from 'framer-motion'
import { useTranslation } from 'react-i18next'

const spaces = [
  {
    labelKey: 'spaces.label_entertainment',
    headingKey: 'spaces.heading_entertainment',
    bodyKey: 'spaces.body_entertainment',
    img: 'https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=900&auto=format&fit=crop&q=80',
    alt: 'Luxury bar interior warm lighting',
    reverse: false,
  },
  {
    labelKey: 'spaces.label_wellness',
    headingKey: 'spaces.heading_wellness',
    bodyKey: 'spaces.body_wellness',
    img: 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?w=900&auto=format&fit=crop&q=80',
    alt: 'Outdoor jacuzzi in forest luxury setting',
    reverse: true,
  },
  {
    labelKey: 'spaces.label_outdoor',
    headingKey: 'spaces.heading_outdoor',
    bodyKey: 'spaces.body_outdoor',
    img: 'https://images.unsplash.com/photo-1439130490301-25e322d88054?w=900&auto=format&fit=crop&q=80',
    alt: 'Outdoor mountain forest terrace evening',
    reverse: false,
  },
]

function SpaceBlock({ space, index }) {
  const { t } = useTranslation()
  const { reverse, img, alt, labelKey, headingKey, bodyKey } = space

  return (
    <div
      className={`grid grid-cols-1 lg:grid-cols-2 gap-0 ${
        index > 0 ? 'border-t border-warm-100' : ''
      }`}
    >
      {/* Image */}
      <motion.div
        initial={{ opacity: 0, x: reverse ? 40 : -40 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true, margin: '-80px' }}
        transition={{ duration: 0.8, ease: 'easeOut' }}
        className={`img-zoom overflow-hidden h-[400px] lg:h-[540px] ${
          reverse ? 'lg:order-2' : 'lg:order-1'
        }`}
      >
        <img
          src={img}
          alt={alt}
          className="w-full h-full object-cover"
          loading="lazy"
        />
      </motion.div>

      {/* Text */}
      <motion.div
        initial={{ opacity: 0, x: reverse ? -40 : 40 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true, margin: '-80px' }}
        transition={{ duration: 0.8, delay: 0.1, ease: 'easeOut' }}
        className={`flex flex-col justify-center px-8 md:px-16 py-16 ${
          reverse ? 'lg:order-1 bg-cream-100' : 'lg:order-2 bg-cream-50'
        }`}
      >
        <p className="section-label mb-5">{t(labelKey)}</p>
        <h2 className="font-display text-3xl md:text-4xl font-normal text-warm-700 leading-tight mb-6">
          {t(headingKey)}
        </h2>
        <p className="font-body text-base font-light text-text-muted leading-[1.8]">
          {t(bodyKey)}
        </p>
        <div className="mt-8 w-12 h-px bg-warm-300" />
      </motion.div>
    </div>
  )
}

export default function Spaces() {
  const { t } = useTranslation()

  return (
    <section id="spaces" className="bg-cream-50">
      <div className="max-content pt-[72px] md:pt-[120px]">
        <div className="text-center mb-16">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="section-label mb-4"
          >
            OUR SPACES
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="section-heading"
          >
            Designed for Living Well
          </motion.h2>
        </div>
      </div>

      <div className="overflow-hidden">
        {spaces.map((space, i) => (
          <SpaceBlock key={i} space={space} index={i} />
        ))}
      </div>

      <div className="pb-[72px] md:pb-[120px]" />
    </section>
  )
}
