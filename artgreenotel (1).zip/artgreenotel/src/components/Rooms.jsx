import { motion } from 'framer-motion'
import { useTranslation } from 'react-i18next'
import { BedDouble, Users, Mountain, Trees, Flame, Home, ArrowUpRight } from 'lucide-react'

const featureIconMap = {
  'King Bed': BedDouble,
  'Queen Bed': BedDouble,
  'Double Bed': BedDouble,
  'Twin/Double': BedDouble,
  '2 Queen Beds': BedDouble,
  '2 Guests': Users,
  '3 Guests': Users,
  '4 Guests': Users,
  '2 Oaspeți': Users,
  '3 Oaspeți': Users,
  '4 Oaspeți': Users,
  'Pat King': BedDouble,
  'Pat Queen': BedDouble,
  'Pat Dublu': BedDouble,
  'Twin/Dublu': BedDouble,
  '2 Paturi Queen': BedDouble,
  'Forest View': Trees,
  'Vedere Pădure': Trees,
  'Mountain View': Mountain,
  'Vedere Munte': Mountain,
  'Balcony': Home,
  'Balcon': Home,
  'Private Terrace': Home,
  'Terasă Privată': Home,
  'Garden Access': Trees,
  'Acces Grădină': Trees,
  'Fireplace': Flame,
  'Șemineu': Flame,
  'Mezzanine': Home,
  'Mezanin': Home,
}

function RoomCard({ room, index }) {
  const { t } = useTranslation()

  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 0.6, delay: (index % 3) * 0.1, ease: 'easeOut' }}
      className="group bg-cream-50 border border-warm-100 flex flex-col hover:shadow-lg transition-shadow duration-300"
    >
      {/* Image */}
      <div className="img-zoom aspect-[3/4] overflow-hidden">
        <img
          src={room.img}
          alt={room.name}
          className="w-full h-full object-cover"
          loading="lazy"
        />
      </div>

      {/* Content */}
      <div className="p-6 flex flex-col flex-1">
        <h3 className="font-display text-2xl font-normal text-warm-700 mb-3">
          {room.name}
        </h3>
        <p className="font-body text-sm font-light text-text-muted leading-relaxed mb-5 flex-1">
          {room.desc}
        </p>

        {/* Feature pills */}
        <div className="flex flex-wrap gap-2 mb-6">
          {room.features.map((feature, i) => {
            const Icon = featureIconMap[feature] || Home
            return (
              <span
                key={i}
                className="flex items-center gap-1.5 font-body text-xs font-medium text-warm-700 bg-cream-100 px-3 py-1.5 border border-warm-100"
              >
                <Icon size={11} className="text-warm-500" />
                {feature}
              </span>
            )
          })}
        </div>

        {/* CTA */}
        <a
          href="https://airbnb.com"
          target="_blank"
          rel="noopener noreferrer"
          className="group/btn font-body text-xs font-medium tracking-wider uppercase border border-warm-500 text-warm-500 px-6 py-3.5 transition-all duration-200 hover:bg-warm-500 hover:text-white flex items-center justify-center gap-2"
        >
          {t('rooms.book_btn')}
          <ArrowUpRight size={13} className="transition-transform group-hover/btn:translate-x-0.5 group-hover/btn:-translate-y-0.5" />
        </a>
      </div>
    </motion.div>
  )
}

export default function Rooms() {
  const { t } = useTranslation()
  const rooms = t('rooms.rooms', { returnObjects: true })

  return (
    <section id="rooms" className="section-pad bg-cream-100">
      <div className="max-content">
        {/* Header */}
        <div className="text-center mb-16">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="section-label mb-4"
          >
            {t('rooms.label')}
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="section-heading mb-4"
          >
            {t('rooms.heading')}
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="font-body text-base font-light text-text-muted max-w-lg mx-auto"
          >
            {t('rooms.subline')}
          </motion.p>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {rooms.map((room, i) => (
            <RoomCard key={i} room={room} index={i} />
          ))}
        </div>
      </div>
    </section>
  )
}
