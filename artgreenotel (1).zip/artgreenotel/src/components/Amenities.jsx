import { motion } from 'framer-motion'
import { useTranslation } from 'react-i18next'
import { Waves, Flame, Thermometer, Zap, Trees, UtensilsCrossed, Car, Coffee } from 'lucide-react'

const icons = [Waves, Flame, Thermometer, Zap, Trees, UtensilsCrossed, Car, Coffee]

export default function Amenities() {
  const { t } = useTranslation()
  const items = t('amenities.items', { returnObjects: true })

  return (
    <section id="amenities" className="section-pad bg-cream-50">
      <div className="max-content">
        {/* Header */}
        <div className="text-center mb-16">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="section-label mb-4"
          >
            {t('amenities.label')}
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="section-heading"
          >
            {t('amenities.heading')}
          </motion.h2>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-px bg-warm-100">
          {items.map((item, i) => {
            const Icon = icons[i] || Waves
            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-40px' }}
                transition={{ duration: 0.5, delay: i * 0.07, ease: 'easeOut' }}
                className="bg-cream-50 p-8 flex flex-col items-center text-center group hover:bg-warm-500 transition-all duration-300"
              >
                <div className="w-14 h-14 rounded-full bg-cream-100 group-hover:bg-warm-700 flex items-center justify-center mb-5 transition-colors duration-300">
                  <Icon size={24} className="text-warm-500 group-hover:text-warm-300 transition-colors duration-300" />
                </div>
                <h3 className="font-body text-sm font-medium text-warm-700 group-hover:text-white mb-2 transition-colors duration-300">
                  {item.name}
                </h3>
                <p className="font-body text-xs font-light text-text-muted group-hover:text-white/80 leading-relaxed transition-colors duration-300">
                  {item.desc}
                </p>
              </motion.div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
