import { motion } from 'framer-motion'
import { useTranslation } from 'react-i18next'
import { Plane, Car, Train, MapPin } from 'lucide-react'

const transportIcons = { plane: Plane, car: Car, train: Train }

export default function Location() {
  const { t } = useTranslation()
  const transport = t('location.transport', { returnObjects: true })

  return (
    <section id="location" className="section-pad bg-cream-100">
      <div className="max-content">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-start">
          {/* Map */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
            className="overflow-hidden border border-warm-100"
          >
            <iframe
              src="https://maps.google.com/maps?q=Sovata,+Romania&z=13&output=embed"
              width="100%"
              height="480"
              style={{ border: 0, display: 'block' }}
              allowFullScreen
              loading="lazy"
              title="ArtGreenOtel location in Sovata, Romania"
            />
          </motion.div>

          {/* Text */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.8, delay: 0.1, ease: 'easeOut' }}
          >
            <p className="section-label mb-5">{t('location.label')}</p>
            <h2 className="section-heading mb-6">{t('location.heading')}</h2>

            <div className="flex items-center gap-2 mb-6">
              <MapPin size={16} className="text-warm-500 flex-shrink-0" />
              <span className="font-body text-sm font-light text-text-muted">
                {t('footer.address')}
              </span>
            </div>

            <p className="font-body text-base font-light text-text-muted leading-[1.8] mb-10">
              {t('location.body')}
            </p>

            {/* Getting here */}
            <div className="border-t border-warm-100 pt-8">
              <p className="font-body text-sm font-medium text-warm-700 mb-6 tracking-wide uppercase">
                {t('location.getting_here')}
              </p>
              <div className="space-y-5">
                {transport.map((item, i) => {
                  const Icon = transportIcons[item.icon] || Car
                  return (
                    <div key={i} className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-full bg-cream-50 border border-warm-100 flex items-center justify-center flex-shrink-0">
                        <Icon size={16} className="text-warm-500" />
                      </div>
                      <span className="font-body text-sm font-light text-text-muted">
                        {item.text}
                      </span>
                    </div>
                  )
                })}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
