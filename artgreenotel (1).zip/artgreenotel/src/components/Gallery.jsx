import { useState } from 'react'
import { motion } from 'framer-motion'
import { useTranslation } from 'react-i18next'
import Lightbox from './Lightbox'

const galleryImages = [
  { src: 'https://images.unsplash.com/photo-1448375240586-882707db888b?w=900&auto=format&fit=crop&q=80', alt: 'Forest view', caption: 'Ancient forest surrounding the villa' },
  { src: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=900&auto=format&fit=crop&q=80', alt: 'Mountain landscape', caption: 'Carpathian mountain panorama' },
  { src: 'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=900&auto=format&fit=crop&q=80', alt: 'Luxury bedroom', caption: 'The Forest Suite' },
  { src: 'https://images.unsplash.com/photo-1600210492493-0946911123ea?w=900&auto=format&fit=crop&q=80', alt: 'Warm interior', caption: 'Fireplace lounge' },
  { src: 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?w=900&auto=format&fit=crop&q=80', alt: 'Jacuzzi outdoor', caption: 'Private outdoor jacuzzi' },
  { src: 'https://images.unsplash.com/photo-1512918728675-ed5a9ecdebfd?w=900&auto=format&fit=crop&q=80', alt: 'Bedroom luxury', caption: 'The Hearth Room' },
  { src: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=900&auto=format&fit=crop&q=80', alt: 'Pool terrace view', caption: 'Outdoor terrace' },
  { src: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=900&auto=format&fit=crop&q=80', alt: 'Sauna interior', caption: 'Finnish sauna' },
  { src: 'https://images.unsplash.com/photo-1618221469555-7f3ad97540d6?w=900&auto=format&fit=crop&q=80', alt: 'Stone interior', caption: 'The Stone Loft' },
  { src: 'https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=900&auto=format&fit=crop&q=80', alt: 'Bar interior', caption: 'The bar lounge' },
  { src: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=900&auto=format&fit=crop&q=80', alt: 'Outdoor dining', caption: 'Al fresco dining' },
  { src: 'https://images.unsplash.com/photo-1439130490301-25e322d88054?w=900&auto=format&fit=crop&q=80', alt: 'Terrace mountain', caption: 'Terrace with mountain views' },
  { src: 'https://images.unsplash.com/photo-1540518614846-7eded433c457?w=900&auto=format&fit=crop&q=80', alt: 'Bedroom canopy', caption: 'The Canopy Suite' },
  { src: 'https://images.unsplash.com/photo-1595576508898-0ad5c879a061?w=900&auto=format&fit=crop&q=80', alt: 'Garden room', caption: 'The Garden Room' },
  { src: 'https://images.unsplash.com/photo-1506059612708-99d6128b4e46?w=900&auto=format&fit=crop&q=80', alt: 'Family room', caption: 'The Family Retreat' },
  { src: 'https://images.unsplash.com/photo-1600566753151-384129cf4e3e?w=900&auto=format&fit=crop&q=80', alt: 'Villa exterior', caption: 'ArtGreenOtel exterior' },
]

// Masonry-style: assign different heights to create visual interest
const heights = [
  'row-span-2', 'row-span-1', 'row-span-1',
  'row-span-1', 'row-span-2', 'row-span-1',
  'row-span-1', 'row-span-1', 'row-span-2',
  'row-span-2', 'row-span-1', 'row-span-1',
  'row-span-1', 'row-span-1', 'row-span-1',
  'row-span-2',
]

export default function Gallery() {
  const { t } = useTranslation()
  const [lightboxIndex, setLightboxIndex] = useState(null)

  const openLightbox = (index) => setLightboxIndex(index)
  const closeLightbox = () => setLightboxIndex(null)
  const prevImage = () => setLightboxIndex((i) => (i - 1 + galleryImages.length) % galleryImages.length)
  const nextImage = () => setLightboxIndex((i) => (i + 1) % galleryImages.length)

  return (
    <section id="gallery" className="section-pad bg-cream-50">
      <div className="max-content">
        {/* Header */}
        <div className="text-center mb-14">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="section-label mb-4"
          >
            {t('gallery.label')}
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="section-heading"
          >
            {t('gallery.heading')}
          </motion.h2>
        </div>

        {/* Masonry grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 grid-rows-auto gap-3 auto-rows-[160px]">
          {galleryImages.map((image, i) => (
            <motion.button
              key={i}
              initial={{ opacity: 0, scale: 0.98 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true, margin: '-40px' }}
              transition={{ duration: 0.5, delay: (i % 4) * 0.08 }}
              onClick={() => openLightbox(i)}
              className={`img-zoom overflow-hidden cursor-pointer focus:outline-none focus:ring-2 focus:ring-warm-500 ${heights[i] || 'row-span-1'}`}
              aria-label={`View ${image.alt}`}
            >
              <img
                src={image.src}
                alt={image.alt}
                className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                loading="lazy"
              />
            </motion.button>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      {lightboxIndex !== null && (
        <Lightbox
          images={galleryImages}
          currentIndex={lightboxIndex}
          onClose={closeLightbox}
          onPrev={prevImage}
          onNext={nextImage}
        />
      )}
    </section>
  )
}
