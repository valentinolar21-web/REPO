import { motion } from 'framer-motion'
import { useTranslation } from 'react-i18next'

const fadeUp = {
  hidden: { opacity: 0, y: 40 },
  visible: (i = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, delay: i * 0.1, ease: 'easeOut' },
  }),
}

export default function About() {
  const { t } = useTranslation()

  const stats = [
    t('about.stat1'),
    t('about.stat2'),
    t('about.stat3'),
    t('about.stat4'),
  ]

  return (
    <section id="about" className="section-pad bg-cream-50">
      <div className="max-content">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24 items-center">
          {/* Image */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: '-80px' }}
            variants={fadeUp}
            className="img-zoom rounded-none overflow-hidden aspect-[3/4] lg:aspect-auto lg:h-[600px]"
          >
            <img
              src="https://images.unsplash.com/photo-1600210492493-0946911123ea?w=900&auto=format&fit=crop&q=80"
              alt="Luxury villa interior with warm fireplace tones"
              className="w-full h-full object-cover"
              loading="lazy"
            />
          </motion.div>

          {/* Text */}
          <div>
            <motion.p
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: '-80px' }}
              variants={fadeUp}
              custom={0}
              className="section-label mb-5"
            >
              {t('about.label')}
            </motion.p>

            <motion.h2
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: '-80px' }}
              variants={fadeUp}
              custom={1}
              className="section-heading mb-8"
            >
              {t('about.heading')}
            </motion.h2>

            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: '-80px' }}
              variants={fadeUp}
              custom={2}
              className="space-y-5 mb-12"
            >
              {['p1', 'p2', 'p3'].map((key) => (
                <p key={key} className="font-body text-base font-light text-text-muted leading-[1.8]">
                  {t(`about.${key}`)}
                </p>
              ))}
            </motion.div>

            {/* Stats row */}
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: '-80px' }}
              variants={fadeUp}
              custom={3}
              className="border-t border-warm-100 pt-8"
            >
              <div className="grid grid-cols-2 gap-y-6 gap-x-4">
                {stats.map((stat, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <div className="w-1 h-8 bg-warm-300 flex-shrink-0" />
                    <span className="font-body text-sm font-medium text-warm-700 leading-tight">
                      {stat}
                    </span>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  )
}
