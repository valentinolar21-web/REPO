import { motion } from 'framer-motion'
import { useTranslation } from 'react-i18next'
import { Briefcase, Cake, ArrowRight } from 'lucide-react'

export default function Events() {
  const { t } = useTranslation()

  const cards = [
    {
      icon: Briefcase,
      headingKey: 'events.corporate_heading',
      bodyKey: 'events.corporate_body',
      ctaKey: 'events.corporate_cta',
      href: 'mailto:events@artgreenotel.ro',
      img: 'https://images.unsplash.com/photo-1521737711867-e3b97375f902?w=800&auto=format&fit=crop&q=80',
    },
    {
      icon: Cake,
      headingKey: 'events.birthday_heading',
      bodyKey: 'events.birthday_body',
      ctaKey: 'events.birthday_cta',
      href: 'mailto:events@artgreenotel.ro',
      img: 'https://images.unsplash.com/photo-1530103862676-de8c9debad1d?w=800&auto=format&fit=crop&q=80',
    },
  ]

  return (
    <section id="events" className="section-pad bg-cream-100">
      <div className="max-content">
        {/* Header */}
        <div className="text-center mb-16">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="section-label mb-4"
          >
            {t('events.label')}
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="section-heading mb-4"
          >
            {t('events.heading')}
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="font-body text-base font-light text-text-muted max-w-2xl mx-auto"
          >
            {t('events.subline')}
          </motion.p>
        </div>

        {/* Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {cards.map((card, i) => {
            const Icon = card.icon
            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-60px' }}
                transition={{ duration: 0.7, delay: i * 0.15, ease: 'easeOut' }}
                className="bg-cream-50 border border-warm-100 group overflow-hidden"
              >
                {/* Image */}
                <div className="img-zoom h-56 overflow-hidden">
                  <img
                    src={card.img}
                    alt={t(card.headingKey)}
                    className="w-full h-full object-cover"
                    loading="lazy"
                  />
                </div>

                {/* Content */}
                <div className="p-8">
                  <div className="w-10 h-10 rounded-full bg-cream-100 flex items-center justify-center mb-5">
                    <Icon size={18} className="text-warm-500" />
                  </div>
                  <h3 className="font-display text-3xl font-normal text-warm-700 mb-4">
                    {t(card.headingKey)}
                  </h3>
                  <p className="font-body text-sm font-light text-text-muted leading-[1.8] mb-8">
                    {t(card.bodyKey)}
                  </p>
                  <a
                    href={card.href}
                    className="group/link font-body text-xs font-medium tracking-wider uppercase text-warm-500 flex items-center gap-2 hover:gap-3 transition-all"
                  >
                    {t(card.ctaKey)}
                    <ArrowRight size={14} />
                  </a>
                </div>
              </motion.div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
