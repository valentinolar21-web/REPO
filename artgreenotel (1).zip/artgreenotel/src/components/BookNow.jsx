import { motion } from 'framer-motion'
import { useTranslation } from 'react-i18next'
import { ExternalLink } from 'lucide-react'

const platforms = [
  {
    name: 'airbnb',
    href: 'https://airbnb.com',
    logo: (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 2C10.5 2 8.5 4.5 7 7.5C5.5 10.5 4 13 4 15C4 17.8 7.6 20 12 20C16.4 20 20 17.8 20 15C20 13 18.5 10.5 17 7.5C15.5 4.5 13.5 2 12 2ZM12 18C8.7 18 6 16.7 6 15C6 13.5 7.2 11.5 8.5 9C9.5 7 10.8 5 12 5C13.2 5 14.5 7 15.5 9C16.8 11.5 18 13.5 18 15C18 16.7 15.3 18 12 18Z"/>
      </svg>
    ),
  },
  {
    name: 'booking',
    href: 'https://booking.com',
    logo: (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
        <path d="M19 3H5C3.9 3 3 3.9 3 5V19C3 20.1 3.9 21 5 21H19C20.1 21 21 20.1 21 19V5C21 3.9 20.1 3 19 3ZM12 17C9.2 17 7 14.8 7 12C7 9.2 9.2 7 12 7C14.8 7 17 9.2 17 12C17 14.8 14.8 17 12 17Z"/>
      </svg>
    ),
  },
  {
    name: 'vrbo',
    href: 'https://vrbo.com',
    logo: (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
        <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
      </svg>
    ),
  },
]

export default function BookNow() {
  const { t } = useTranslation()

  return (
    <section id="book" className="relative section-pad overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1448375240586-882707db888b?w=1920&auto=format&fit=crop&q=85"
          alt="ArtGreenOtel forest villa"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-warm-700/85" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-content text-center">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="font-body text-xs font-medium tracking-[0.25em] uppercase text-warm-300 mb-6"
        >
          BOOK YOUR STAY
        </motion.p>

        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="font-display text-4xl md:text-5xl font-light text-white leading-tight mb-6"
        >
          {t('book.heading')}
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="font-body text-base font-light text-white/70 mb-14 max-w-lg mx-auto"
        >
          {t('book.subline')}
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.3 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          {platforms.map((platform, i) => (
            <a
              key={i}
              href={platform.href}
              target="_blank"
              rel="noopener noreferrer"
              className="group flex items-center gap-3 font-body text-xs font-medium tracking-wider uppercase border border-white/40 text-white px-8 py-4 hover:bg-white hover:text-warm-700 transition-all duration-300 min-w-[220px] justify-center"
            >
              <span className="text-warm-300 group-hover:text-warm-500 transition-colors">
                {platform.logo}
              </span>
              {t(`book.${platform.name}`)}
              <ExternalLink size={11} className="opacity-50" />
            </a>
          ))}
        </motion.div>

        {/* Divider + note */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.5 }}
          className="font-body text-xs font-light text-white/40 mt-10"
        >
          {t('footer.email')} · {t('footer.phone')}
        </motion.p>
      </div>
    </section>
  )
}
