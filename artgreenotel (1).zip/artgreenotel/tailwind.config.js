/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        cream: {
          50: '#FDFAF5',
          100: '#F5EFE0',
        },
        warm: {
          100: '#EDE0CC',
          300: '#C4A882',
          500: '#8B6E4E',
          700: '#5C4230',
        },
        forest: {
          500: '#4A7C4A',
          700: '#2D4A2D',
        },
        'text-main': '#2A2218',
        'text-muted': '#7A6A55',
      },
      fontFamily: {
        display: ['"Cormorant Garamond"', 'Georgia', 'serif'],
        body: ['Jost', 'system-ui', 'sans-serif'],
      },
      fontSize: {
        hero: ['72px', { lineHeight: '1.05', fontWeight: '300' }],
        'section-title': ['48px', { lineHeight: '1.15', fontWeight: '400' }],
        'sub-title': ['28px', { lineHeight: '1.3', fontWeight: '400' }],
      },
      letterSpacing: {
        widest: '0.12em',
        wider: '0.1em',
      },
      maxWidth: {
        content: '1280px',
      },
      spacing: {
        section: '120px',
        'section-mobile': '72px',
      },
      backgroundImage: {
        'gradient-overlay': 'linear-gradient(to top, rgba(0,0,0,0.6) 0%, rgba(0,0,0,0.2) 50%, transparent 100%)',
      },
    },
  },
  plugins: [],
}
